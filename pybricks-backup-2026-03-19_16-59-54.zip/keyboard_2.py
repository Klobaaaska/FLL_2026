from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor
from pybricks.parameters import Direction, Port
from pybricks.robotics import DriveBase
from usys import stdin
from uselect import poll

hub = PrimeHub()
keyboard = poll()
keyboard.register(stdin)

Right = Motor(Port.E, Direction.CLOCKWISE)
Left = Motor(Port.F, Direction.COUNTERCLOCKWISE)
RukaRight = Motor(Port.D, Direction.CLOCKWISE)
RukaLeft = Motor(Port.C, Direction.COUNTERCLOCKWISE)
drive_base = DriveBase(Left, Right, 56, 81)

def run_drive(speed):
    """Control the drive base with a given speed. 
       Positive speed for forward, negative for backward."""
    drive_base.straight(speed)

def run_arm(motor, d):
    """Run a specific arm motor by a given angle."""
    motor.dc(d)

def run_mission(mission):
    mise = "Mise " + str(mission)
    from FLL2026 import mise

    mise()

while True:
    if keyboard.poll(0):
        key = stdin.read(1)

        if key == "c":  # Stop all motors
            run_drive(0)
        elif key == "w":  # Forward
            run_drive(100)  # Continuous forward speed
        elif key == "s":  # Backward
            run_drive(-100)  # Continuous backward speed
        elif key == "a":  # Turn left
            drive_base.turn(-30)
        elif key == "d":  # Turn right
            drive_base.turn(30)
        elif key == "h":  # Raise right arm
            run_arm(RukaRight, 15)
        elif key == "j":  # Lower right arm
            run_arm(RukaRight, -15)
        elif key == "f":  # Raise left arm
            run_arm(RukaLeft, -50)
        elif key == "g":  # Lower left arm
            run_arm(RukaLeft, 50)
        elif key == "+":
            run_mission(1)
        elif key == "ě":
            run_mission(2)
        elif key == "š":
            run_mission(3)
        elif key == "č":
            run_mission(4)
        elif key == " ":
            run_drive(0)
            Left.stop()
            Right.stop()
            RukaLeft.stop()
            RukaRight.stop()
        else:
            print(f'Key: "{key}"')
    else:
        run_drive(0)
        Left.stop()
        Right.stop()
