from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch, hub_menu

hub = PrimeHub()

select = hub_menu("1", "2", "3")

if select == "1":
    print("1")
elif select == "2":
    print("2")
elif select == "3":
    print("3")































    d