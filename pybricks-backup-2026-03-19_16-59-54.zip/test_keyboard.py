from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor
from pybricks.parameters import Direction, Port, Stop
from pybricks.robotics import DriveBase
from usys import stdin
from uselect import poll

hub = PrimeHub()
keyboard = poll()
keyboard.register(stdin)

Right = Motor(Port.E, Direction.CLOCKWISE)
Left = Motor(Port.F, Direction.COUNTERCLOCKWISE)
RukaRight = Motor(Port.D, Direction.CLOCKWISE)
RukaLeft = Motor(Port.C, Direction.COUNTERCLOCKWISE)
drive_base = DriveBase(Left, Right, 56, 81)

def run_drive(command):
    if command == "forward":
        Right.run_angle(100, 20)
        Left.run_angle(100, 20)
    elif command == "backward":
        Right.run_angle(100, -20)
        Left.run_angle(100, -20)
    elif command == "turn_left":
        drive_base.turn(-30)  # Speed value for left turn
    elif command == "turn_right":
        drive_base.turn(30)  # Speed value for right turn
    elif command == "right_up":
        RukaRight.run_angle(100, 15)
    elif command == "right_down":
        RukaRight.run_angle(100, -15)
    elif command == "left_up":
        RukaLeft.run_angle(100, -15)
    elif command == "left_down":
        RukaLeft.run_angle(100, 15)
    else:
        drive_base.stop()
        Right.stop()
        Left.stop()
        RukaRight.stop()
        RukaLeft.stop()

while True:
    if keyboard.poll(0):
        key = stdin.read(1)

        if key == "c":
            run_drive("")
        elif key == "w":
            run_drive("forward")
        elif key == "s":
            run_drive("backward")
        elif key == "a":
            run_drive("turn_left")
        elif key == "d":
            run_drive("turn_right")
        elif key == "q":
            run_drive("right_up")
        elif key == "e":
            run_drive("right_down")
        elif key == "r":
            run_drive("left_up")
        elif key == "f":
            run_drive("left_down")
    else:
        run_drive("")  # Stop the drive base if no key is pressed
